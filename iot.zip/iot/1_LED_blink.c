int LED = 13;
void setup()
{
	pinMode(LED, OUTPUT);
}
void loop()
{
	digitalWrite(LED, HIGH);
	delay(1000); // Wait for 1000 millisecond(s)
	digitalWrite(LED, LOW);
	delay(1000); // Wait for 1000 millisecond(s)
}